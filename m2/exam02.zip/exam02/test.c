#include <unistd.h>

char *self_double_check(char *str)
{
	int	i;
	int	j;

	i = 0;
	while (*str)
	{
		j = 1;
		while (str[j])
		{
			if (*str == str[j])
				*str++ = 1;
			j++;
		}
		i++;
	}
	return (str);
}

int main(int argc, char *argv[])
{
	int	i;
	int	j;
	int	cnt;
	char *double_remove_str;
	cnt = 0;
	if (argc == 3)
	{
		i = 0;
		while (argv[1][i])
		{
			j = 0;
			while (argv[2][j])
			{
				if (argv[1][i] == argv[2][j])
				{
					write(1, &argv[1][i], 1);
					break ;
				}
				j++;
			}
			i++;
		}
		double_remove_str = self_double_check(argv[1]);
	}
	write(1, "\n", 1);
}

